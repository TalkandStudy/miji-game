import pygame
import sys
import random
import math

# 初始化Pygame
pygame.init()

# 游戏窗口设置
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("双近防炮拦截导弹")

# 颜色定义（调整子弹颜色以适配白色背景）
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)  # 鼠标发射子弹颜色
GREEN = (0, 255, 0) # 1键发射子弹颜色（区分射速）

# 加载图片资源（注意：需提前准备img文件夹及对应图片）
try:
    # 近防炮图片（居中）- 先加载原图，逆时针旋转90度后再缩放
    cannon_img = pygame.image.load("img/jfp.png").convert_alpha()
    # 核心修改：将近防炮图片逆时针旋转90度（角度改为-90）
    cannon_img = pygame.transform.rotate(cannon_img, -90)
    # 缩放近防炮图片至合适大小
    cannon_img = pygame.transform.scale(cannon_img, (80, 80))
    # 导弹图片
    missile_img = pygame.image.load("img/dd.png").convert_alpha()
    missile_img = pygame.transform.scale(missile_img, (40, 20))
except FileNotFoundError:
    # 图片缺失时的替代图形（避免程序崩溃）
    print("警告：未找到图片文件，使用默认图形替代")
    cannon_img = pygame.Surface((80, 80), pygame.SRCALPHA)
    pygame.draw.circle(cannon_img, (100, 100, 100), (40, 40), 40)
    missile_img = pygame.Surface((40, 20), pygame.SRCALPHA)
    pygame.draw.rect(missile_img, RED, (0, 0, 40, 20))

# 子弹类（新增颜色参数区分射速）
class Bullet:
    def __init__(self, x, y, angle, color=BLUE):
        self.x = x
        self.y = y
        self.speed = 15
        self.angle = angle
        self.radius = 3
        self.lifetime = 60  # 子弹存活帧数
        self.active = True
        self.color = color  # 子弹颜色

    def update(self):
        # 根据角度更新子弹位置
        self.x += math.cos(self.angle) * self.speed
        self.y += math.sin(self.angle) * self.speed
        self.lifetime -= 1
        # 超出屏幕或寿命耗尽则失效
        if (self.x < 0 or self.x > WIDTH or self.y < 0 or self.y > HEIGHT or 
            self.lifetime <= 0):
            self.active = False

    def draw(self):
        pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), self.radius)

# 导弹类
class Missile:
    def __init__(self):
        # 随机生成导弹的初始位置（屏幕边缘）
        side = random.choice(["top", "bottom", "left", "right"])
        if side == "top":
            self.x = random.randint(0, WIDTH)
            self.y = -50
        elif side == "bottom":
            self.x = random.randint(0, WIDTH)
            self.y = HEIGHT + 50
        elif side == "left":
            self.x = -50
            self.y = random.randint(0, HEIGHT)
        else:  # right
            self.x = WIDTH + 50
            self.y = random.randint(0, HEIGHT)
        
        # 导弹朝向屏幕中心区域
        target_x = WIDTH/2 + random.randint(-50, 50)  # 目标分散，避免只打中心点
        target_y = HEIGHT/2 + random.randint(-50, 50)
        self.angle = math.atan2(target_y - self.y, target_x - self.x)
        self.speed = random.uniform(1, 3)  # 随机速度
        self.active = True
        self.radius = 10  # 碰撞检测半径

    def update(self):
        # 更新位置
        self.x += math.cos(self.angle) * self.speed
        self.y += math.sin(self.angle) * self.speed
        # 到达中心或超出屏幕则失效
        if (abs(self.x - WIDTH/2) < 20 and abs(self.y - HEIGHT/2) < 20 or
            self.x < -100 or self.x > WIDTH + 100 or
            self.y < -100 or self.y > HEIGHT + 100):
            self.active = False

    def draw(self):
        # 旋转导弹图片（可选）
        rotated_missile = pygame.transform.rotate(missile_img, -math.degrees(self.angle))
        rect = rotated_missile.get_rect(center=(self.x, self.y))
        screen.blit(rotated_missile, rect)

# 近防炮类（新增射速参数）
class Cannon:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.angle = 0  # 初始角度
        self.base_fire_rate = 5  # 基础发射间隔（帧数）- 鼠标发射射速
        self.fast_fire_rate = 2  # 快速发射间隔（帧数）- 1键发射射速
        self.fire_timer = 0
        self.current_fire_rate = self.base_fire_rate  # 当前使用的射速

    def update(self, mouse_pos):
        # 计算朝向鼠标的角度
        dx = mouse_pos[0] - self.x
        dy = mouse_pos[1] - self.y
        self.angle = math.atan2(dy, dx)
        # 更新发射计时器
        if self.fire_timer > 0:
            self.fire_timer -= 1

    def set_fire_rate(self, is_fast):
        # 设置射速：True=快速（1键），False=基础（鼠标）
        self.current_fire_rate = self.fast_fire_rate if is_fast else self.base_fire_rate

    def draw(self):
        # 旋转近防炮图片（基于朝向鼠标的角度）
        rotated_cannon = pygame.transform.rotate(cannon_img, -math.degrees(self.angle))
        rect = rotated_cannon.get_rect(center=(self.x, self.y))
        screen.blit(rotated_cannon, rect)

    def can_fire(self):
        return self.fire_timer == 0

    def fire(self, is_fast=False):
        if self.can_fire():
            self.set_fire_rate(is_fast)
            self.fire_timer = self.current_fire_rate
            # 创建子弹（从炮口位置发射）
            bullet_x = self.x + math.cos(self.angle) * 40
            bullet_y = self.y + math.sin(self.angle) * 40
            # 快速发射的子弹用绿色区分
            bullet_color = GREEN if is_fast else BLUE
            return Bullet(bullet_x, bullet_y, self.angle, bullet_color)
        return None

# 碰撞检测函数
def check_collision(bullet, missile):
    dx = bullet.x - missile.x
    dy = bullet.y - missile.y
    distance = math.hypot(dx, dy)
    return distance < (bullet.radius + missile.radius)

# 主游戏函数
def main():
    clock = pygame.time.Clock()
    # 创建两门近防炮：分别在中心左右两侧
    cannon1 = Cannon(WIDTH//2 - 80, HEIGHT//2)
    cannon2 = Cannon(WIDTH//2 + 80, HEIGHT//2)
    cannons = [cannon1, cannon2]  # 炮列表统一管理
    
    bullets = []
    missiles = []
    missile_spawn_timer = 0
    missile_spawn_interval = 60  # 每60帧生成一个导弹（可调整）
    
    # 按键状态
    key_1_pressed = False  # 数字1键是否按住

    running = True
    while running:
        # 控制帧率
        clock.tick(60)
        screen.fill(WHITE)  # 背景改为白色

        # 获取鼠标状态
        mouse_pos = pygame.mouse.get_pos()
        mouse_left_pressed = pygame.mouse.get_pressed()[0]  # 鼠标左键是否按住

        # 事件处理
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            # 键盘按下/松开事件
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    key_1_pressed = True
            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_1:
                    key_1_pressed = False

        # 更新所有近防炮（朝向鼠标）
        for cannon in cannons:
            cannon.update(mouse_pos)

        # 发射逻辑：鼠标左键发射（基础射速）
        if mouse_left_pressed:
            for cannon in cannons:
                bullet = cannon.fire(is_fast=False)
                if bullet:
                    bullets.append(bullet)
        # 数字1键发射（快速射速）
        if key_1_pressed:
            for cannon in cannons:
                bullet = cannon.fire(is_fast=True)
                if bullet:
                    bullets.append(bullet)

        # 更新并绘制子弹
        active_bullets = []
        for bullet in bullets:
            bullet.update()
            if bullet.active:
                bullet.draw()
                active_bullets.append(bullet)
        bullets = active_bullets

        # 生成导弹
        missile_spawn_timer += 1
        if missile_spawn_timer >= missile_spawn_interval:
            missiles.append(Missile())
            missile_spawn_timer = 0
            # 随机调整生成间隔，增加随机性
            missile_spawn_interval = random.randint(40, 80)

        # 更新并绘制导弹，检测碰撞
        active_missiles = []
        for missile in missiles:
            missile.update()
            hit = False
            # 检测子弹与导弹的碰撞
            for bullet in bullets:
                if check_collision(bullet, missile):
                    bullet.active = False
                    hit = True
                    break
            if not hit and missile.active:
                missile.draw()
                active_missiles.append(missile)
        missiles = active_missiles

        # 绘制所有近防炮（最后绘制，确保在最上层）
        for cannon in cannons:
            cannon.draw()



        # 更新屏幕
        pygame.display.flip()

    # 退出游戏
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()