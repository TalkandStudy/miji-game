import pygame
import sys
import random
import math

# 初始化Pygame
pygame.init()

# 游戏窗口设置
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("近防炮拦截导弹")

# 颜色定义（调整子弹颜色以适配白色背景）
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)  # 替换子弹颜色为蓝色（对比度更高）

# 加载图片资源（注意：需提前准备img文件夹及对应图片）
try:
    # 近防炮图片（居中）- 先加载原图，逆时针旋转90度后再缩放
    cannon_img = pygame.image.load("img/jfp.png").convert_alpha()
    # 核心修改：将近防炮图片逆时针旋转90度（角度改为-90）
    cannon_img = pygame.transform.rotate(cannon_img, -90)
    # 缩放近防炮图片至合适大小
    cannon_img = pygame.transform.scale(cannon_img, (80, 80))
    # 导弹图片
    missile_img = pygame.image.load("img/dd.png").convert_alpha()
    missile_img = pygame.transform.scale(missile_img, (40, 20))
except FileNotFoundError:
    # 图片缺失时的替代图形（避免程序崩溃）
    print("警告：未找到图片文件，使用默认图形替代")
    cannon_img = pygame.Surface((80, 80), pygame.SRCALPHA)
    pygame.draw.circle(cannon_img, (100, 100, 100), (40, 40), 40)
    missile_img = pygame.Surface((40, 20), pygame.SRCALPHA)
    pygame.draw.rect(missile_img, RED, (0, 0, 40, 20))

# 子弹类
class Bullet:
    def __init__(self, x, y, angle):
        self.x = x
        self.y = y
        self.speed = 15
        self.angle = angle
        self.radius = 3
        self.lifetime = 60  # 子弹存活帧数
        self.active = True

    def update(self):
        # 根据角度更新子弹位置
        self.x += math.cos(self.angle) * self.speed
        self.y += math.sin(self.angle) * self.speed
        self.lifetime -= 1
        # 超出屏幕或寿命耗尽则失效
        if (self.x < 0 or self.x > WIDTH or self.y < 0 or self.y > HEIGHT or 
            self.lifetime <= 0):
            self.active = False

    def draw(self):
        pygame.draw.circle(screen, BLUE, (int(self.x), int(self.y)), self.radius)  # 子弹改为蓝色

# 导弹类
class Missile:
    def __init__(self):
        # 随机生成导弹的初始位置（屏幕边缘）
        side = random.choice(["top", "bottom", "left", "right"])
        if side == "top":
            self.x = random.randint(0, WIDTH)
            self.y = -50
        elif side == "bottom":
            self.x = random.randint(0, WIDTH)
            self.y = HEIGHT + 50
        elif side == "left":
            self.x = -50
            self.y = random.randint(0, HEIGHT)
        else:  # right
            self.x = WIDTH + 50
            self.y = random.randint(0, HEIGHT)
        
        # 导弹朝向屏幕中心
        target_x, target_y = WIDTH/2, HEIGHT/2
        self.angle = math.atan2(target_y - self.y, target_x - self.x)
        self.speed = random.uniform(1, 3)  # 随机速度
        self.active = True
        self.radius = 10  # 碰撞检测半径

    def update(self):
        # 更新位置
        self.x += math.cos(self.angle) * self.speed
        self.y += math.sin(self.angle) * self.speed
        # 到达中心或超出屏幕则失效
        if (abs(self.x - WIDTH/2) < 10 and abs(self.y - HEIGHT/2) < 10 or
            self.x < -100 or self.x > WIDTH + 100 or
            self.y < -100 or self.y > HEIGHT + 100):
            self.active = False

    def draw(self):
        # 旋转导弹图片（可选）
        rotated_missile = pygame.transform.rotate(missile_img, -math.degrees(self.angle))
        rect = rotated_missile.get_rect(center=(self.x, self.y))
        screen.blit(rotated_missile, rect)

# 近防炮类
class Cannon:
    def __init__(self):
        self.x = WIDTH // 2
        self.y = HEIGHT // 2
        self.angle = 0  # 初始角度
        self.fire_rate = 5  # 发射间隔（帧数）
        self.fire_timer = 0

    def update(self, mouse_pos):
        # 计算朝向鼠标的角度
        dx = mouse_pos[0] - self.x
        dy = mouse_pos[1] - self.y
        self.angle = math.atan2(dy, dx)
        # 更新发射计时器
        if self.fire_timer > 0:
            self.fire_timer -= 1

    def draw(self):
        # 旋转近防炮图片（基于朝向鼠标的角度）
        rotated_cannon = pygame.transform.rotate(cannon_img, -math.degrees(self.angle))
        rect = rotated_cannon.get_rect(center=(self.x, self.y))
        screen.blit(rotated_cannon, rect)

    def can_fire(self):
        return self.fire_timer == 0

    def fire(self):
        if self.can_fire():
            self.fire_timer = self.fire_rate
            # 创建子弹（从炮口位置发射）
            bullet_x = self.x + math.cos(self.angle) * 40
            bullet_y = self.y + math.sin(self.angle) * 40
            return Bullet(bullet_x, bullet_y, self.angle)
        return None

# 碰撞检测函数
def check_collision(bullet, missile):
    dx = bullet.x - missile.x
    dy = bullet.y - missile.y
    distance = math.hypot(dx, dy)
    return distance < (bullet.radius + missile.radius)

# 主游戏函数
def main():
    clock = pygame.time.Clock()
    cannon = Cannon()
    bullets = []
    missiles = []
    missile_spawn_timer = 0
    missile_spawn_interval = 60  # 每60帧生成一个导弹（可调整）

    running = True
    while running:
        # 控制帧率
        clock.tick(60)
        screen.fill(WHITE)  # 背景改为白色

        # 获取鼠标状态
        mouse_pos = pygame.mouse.get_pos()
        mouse_pressed = pygame.mouse.get_pressed()[0]  # 左键是否按住

        # 事件处理
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # 更新近防炮
        cannon.update(mouse_pos)

        # 发射子弹（按住鼠标时持续发射）
        if mouse_pressed:
            bullet = cannon.fire()
            if bullet:
                bullets.append(bullet)

        # 更新并绘制子弹
        active_bullets = []
        for bullet in bullets:
            bullet.update()
            if bullet.active:
                bullet.draw()
                active_bullets.append(bullet)
        bullets = active_bullets

        # 生成导弹
        missile_spawn_timer += 1
        if missile_spawn_timer >= missile_spawn_interval:
            missiles.append(Missile())
            missile_spawn_timer = 0
            # 随机调整生成间隔，增加随机性
            missile_spawn_interval = random.randint(40, 80)

        # 更新并绘制导弹，检测碰撞
        active_missiles = []
        for missile in missiles:
            missile.update()
            hit = False
            # 检测子弹与导弹的碰撞
            for bullet in bullets:
                if check_collision(bullet, missile):
                    bullet.active = False
                    hit = True
                    break
            if not hit and missile.active:
                missile.draw()
                active_missiles.append(missile)
        missiles = active_missiles

        # 绘制近防炮（最后绘制，确保在最上层）
        cannon.draw()

        # 更新屏幕
        pygame.display.flip()

    # 退出游戏
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()